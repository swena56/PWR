Polsedit 1.0.0.5
User Policies Editor

Description:
Polsedit is a freeware utility that allows you to modify user policies
such as user account rights and user privileges on a local or remote
Windows NT-based system. This can be useful when for some reason you
are unable to run secpol.msc snap-in, for example, XP Home and Vista
Home do not have secpol.msc at all. The user interface of Polsedit is
very similar to the standard policies editor from Windows, but it also
displays some internal data, which can be useful for developers.

Benefits:
1) Modify user account rights and user privileges;
2) Modify user policies on a local or remote system;
3) Modify user policies on XP Home and Vista Home,
where it is not available by default;
4) Enjoy XP-like interface when modifying
user policies on Windows NT/2000;
5) View internal useful for developers data.

System requirements:
Windows NT/2000/XP/2003/Vista/2008/7/2012/8 Desktop

Installation:
Download archive from http://www.southsoftware.com/polsedit.zip,
unzip it anywhere on your hard drive and start polseditx32.exe file.
If you are running a 64-bit Windows, you can also start
polseditx64.exe file instead of polseditx32.exe.

Web site:
http://www.southsoftware.com/
